export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyD-A-5p8HuvKDXuX-plZhdBp4BAPLSrDSo",
    authDomain: "angular-indra-anabel-11-10.firebaseapp.com",
    projectId: "angular-indra-anabel-11-10",
    storageBucket: "angular-indra-anabel-11-10.appspot.com",
    messagingSenderId: "880712162032",
    appId: "1:880712162032:web:4d5a6a4175e3481e6bc035"
  }
};
