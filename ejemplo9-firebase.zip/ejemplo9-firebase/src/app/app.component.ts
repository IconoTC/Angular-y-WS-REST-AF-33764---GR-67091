import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AgendaService } from './services/agenda.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  amigos: any[] = [];
  id: string = '';
  contacto: any;
  mostrar: boolean = false;

  amigoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7,9]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
    agendaService.getAll().subscribe(datos => {
      console.log(datos);

      // limpiando el array
      this.amigos = [];

      datos.forEach(item => {
        this.amigos.push(item.payload.doc.data());
        this.amigos[this.amigos.length - 1].id = item.payload.doc.id;
      });
    });
  }

  ejemplo(){
    this.amigoForm.reset();
    this.mostrar = false;
  }

  buscar():void{
    this.agendaService.buscarAmigo(this.id).subscribe(item => {
      this.contacto = item.payload.data();
      this.id = item.payload.id;
    })
  }

  borrar(){
    this.agendaService.eliminar(this.id)
      .then(() => {
        alert("Contacto eliminado");
        this.contacto = null;
        this.id = '';
      })
      .catch((error) => {
        console.log(error);
      });
  }

  modificar(){
    this.amigoForm.setValue(this.contacto);
    this.mostrar = true;
  }

  guardar(){
    this.agendaService.modificar(this.id, this.amigoForm.value)
      .then(() => {
        this.mostrar = false;
        setTimeout(() => {
          this.contacto = null;
          this.id = '';
          this.amigoForm.reset();
          alert("Contacto modificado");
        }, 1000 );
      })
      .catch((error) => {
        console.log(error);
      });
  }

  alta(): void{
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then(() => {
        alert("Contacto creado");
        this.amigoForm.reset();
      })
      .catch((error) => {
        console.log(error);
      });
  }


}


