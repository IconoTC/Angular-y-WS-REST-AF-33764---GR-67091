import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ContactoService } from 'src/app/services/contacto.service';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {

  contactoForm = new FormGroup({
    nombre: new FormControl(), 
    email: new FormControl(), 
    telefono: new FormControl(), 
    asunto: new FormControl(), 
    mensaje: new FormControl()
  })

  constructor(private contactoService: ContactoService) { }

  enviar(){
    this.contactoService.agregar(this.contactoForm.value)
      .then(() => {
        alert("Mensaje guardado");
        this.contactoForm.reset();
      })
      .catch((error) => {
        console.log(error);
      })
  }

  ngOnInit(): void {
  }

}
