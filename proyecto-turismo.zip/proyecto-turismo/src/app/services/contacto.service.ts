import { Injectable } from '@angular/core';
import { AngularFirestore, DocumentReference } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class ContactoService {

  private db = "/contactos";

  constructor(private angularFirestore: AngularFirestore) { }

  agregar(contacto: any): Promise<DocumentReference<unknown>>{
    return this.angularFirestore.collection(this.db).add(contacto);
  }
}
