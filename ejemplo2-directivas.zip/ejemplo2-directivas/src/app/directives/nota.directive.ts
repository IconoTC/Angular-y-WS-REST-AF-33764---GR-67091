import { Directive, ElementRef, Input, OnInit, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appNota]'
})
export class NotaDirective implements OnInit{

  @Input('appNota')
  alumno: any;

  // En el constructor inyectamos los recursos a utilizar
  constructor(private renderer: Renderer2, private elRef: ElementRef) { }

  // Este metodo se ejecuta cada vez que recibe un alumno
  ngOnInit(): void {
    if (this.alumno.nota >= 5){
      // this.renderer.setProperty(elemento, propiedad, valor)
      this.renderer.setProperty(this.elRef.nativeElement, "innerHTML", 
        `${this.alumno.nombre} ${this.alumno.apellido} ${this.alumno.nota} - APROBADO`);
    } else {
      this.renderer.setProperty(this.elRef.nativeElement, "innerHTML", 
        `${this.alumno.nombre} ${this.alumno.apellido} ${this.alumno.nota} - SUSPENSO`);
    }
  }

}
