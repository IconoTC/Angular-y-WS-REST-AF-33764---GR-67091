import { Component, OnInit } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  amigos: any[] = [];
  id: number = 0;
  contacto: any;
  mostrar: boolean = false;

  amigoForm = new FormGroup({
    id: new FormControl(this.prueba(), [Validators.required, Validators.min(1)]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7,9]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){}

  prueba(): number{
    return 0;
  }

  ejemplo(){
    alert("Has pulsado sobre esta pestaña");
    this.amigoForm.reset();
    this.mostrar = false;
  }

  buscar():void{
    this.contacto = this.agendaService.buscarAmigo(this.id);
  }

  borrar(){
    this.agendaService.eliminar(this.id);
    this.contacto = null;
    this.id = 0;
  }

  modificar(){
    this.amigoForm.setValue(this.contacto);
    this.mostrar = true;
  }

  guardar(){
    this.agendaService.modificar(this.amigoForm.value);
    this.mostrar = false;
    this.contacto = null;
    this.id = 0;
    this.amigoForm.reset();
  }

  alta(): void{
    console.log(this.amigoForm);
    this.agendaService.nuevoAmigo(this.amigoForm.value);
    // Limpiar el formulario
    this.amigoForm.reset();
  }

  ngOnInit(): void {
    this.amigos = this.agendaService.getAll();
  }

}
